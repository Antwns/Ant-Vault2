﻿using WatsonTcp;
using System.Threading;
using System.Windows;
using System.Windows.Media;

namespace AntVault2Client.ClientWorkers
{
    class LoginClientWorker
    {
        public static bool SetUpConnection = false;
        public static string CurrentUser;
        public static bool CanConnect = false;
        public static WatsonTcpClient AntVaultClient = new WatsonTcpClient("AntMax.ddns.net", 8910);

        internal static void SetUpClients()
        {
            AntVaultClient.Events.MessageReceived += MainClientWorker.AntVaultClient_DataReceived;
        }

        internal static void DoAuthentication(string Username, string Password)
        {
            CurrentUser = Username;
            try
            {
                AntVaultClient.Start();
                AntVaultClient.Keepalive.EnableTcpKeepAlives = true;
                AntVaultClient.Keepalive.TcpKeepAliveInterval = 5;
                AntVaultClient.Keepalive.TcpKeepAliveTime = 5;
                AntVaultClient.Keepalive.TcpKeepAliveRetryCount = 5;
                AntVaultClient.Send("/NewConnection -U " + Username + " -P " + Password + ".");//NewConnection -U Username -P Password.
            }
            catch
            {
                MessageBox.Show("Server is offline, therefore the authentication process could not take place, please try again later!", "Error! Server offline!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
