﻿namespace AntVault2Server.WindowControllers
{
    class MainWindowController
    {
        public static Windows.MainWindow MainWindow = new Windows.MainWindow();
    }
}
